﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO_file
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = @"D:\My Folder\Hello World.txt";
            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            FileInfo[] files = directoryInfo.GetFiles("*.*");
            if (!File.Exists(path))
            {
                using (StreamWriter streamWriter = File.CreateText(path))
               {
                    streamWriter.WriteLine("I love C#..!");
               }
            }
            //File.WriteAllText(@"D:\My Folder\Hello World.txt", "I love C#..!");
            //Console.WriteLine();
            foreach (FileInfo fileInfo in files)
            {
                Console.WriteLine("File Name : {0}", fileInfo.Name);
                Console.WriteLine("Length : {0}", fileInfo.Length);
                Console.WriteLine("Creation time : {0}", fileInfo.CreationTime);
                Console.WriteLine("Attributes : {0}", fileInfo.Attributes.ToString());
            }
        }
    }
}
