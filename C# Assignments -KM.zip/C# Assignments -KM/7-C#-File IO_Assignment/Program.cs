﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_IO_assignment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = @"E:\My Directory";
            DirectoryInfo dir = new DirectoryInfo(path);
            dir.Create();
            dir.CreateSubdirectory("Sub directory created..");
            Console.WriteLine("Directory created..");
            Console.ReadLine();
        }
    }
}
