﻿using System;

namespace Ass3_a_Inheritance
{
    class Employee
    {
        protected int Empno { get; set; }
        protected string EmpName { get; set; }
        protected double Salary { get; set; }
        protected double TDS { get; set; }
        protected double DA { get; set; }
        protected double TA { get; set; }
        protected double PF { get; set; }
        protected double HRA { get; set; }
        protected double GrossSalary { get; set; }
        protected double NetSalary { get; set; }

        public Employee(int Eno, string EName, double Sal)
        {
            Empno = Eno;
            EmpName = EName;
            Salary = Sal;

            if (Salary < 5000)
            {
                HRA = Salary * 10 / 100;
                TA = Salary * 5 / 100;
                DA = Salary * 15 / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }

            else if (Salary < 10000)
            {
                HRA = Salary * 15 / 100;
                TA = Salary * 10 / 100;
                DA = Salary * 20 / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }

            else if (Salary < 15000)
            {
                HRA = Salary *  20/ 100;
                TA = Salary *  15/ 100;
                DA = Salary *  25/ 100;
                GrossSalary = Salary + HRA + TA + DA;
            }

            else if (Salary < 20000)
            {
                HRA = Salary * 25 / 100;
                TA = Salary * 20 / 100;
                DA = Salary * 30 / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }

            else
            {
                HRA = Salary * 30 / 100;
                TA = Salary * 25 / 100;
                DA = Salary * 35 / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }
        }



        public virtual void CalculateSalary()
        {
            PF = GrossSalary * 10 / 100;
            TDS = GrossSalary * 18 / 100;
            NetSalary = GrossSalary - (PF + TDS);
        }
        public virtual void Gsal()
        {
            Console.WriteLine(GrossSalary);
        }
    }

    class Manager : Employee
    {
        private double PetrolAllowance { get; set; }
        private double FoodAllowance { get; set; }
        private double OtherAllowance { get; set; }

        public Manager(int Empno, string EmpName, double Sal) : base(Empno, EmpName, Sal)
        {
            PetrolAllowance = Sal * 8 / 100;
            FoodAllowance = Sal * 13 / 100;
            OtherAllowance = Sal * 3 / 100;
        }

        public override void Gsal()
        {
            GrossSalary = (GrossSalary + PetrolAllowance + FoodAllowance + OtherAllowance);
            Console.WriteLine(GrossSalary);
        }

        public override void CalculateSalary()
        {
            NetSalary = GrossSalary - (PF = TDS);
        }

    }

    class MarketingExe : Employee
    {
        private double Kilometertravel { get; set; }
        private double TourAllowance { get; set; }
        private double TelephoneAllowance { get; set; }

        public MarketingExe(int Eno, string EmpName, double Sal, double kmt) : base(Eno,EmpName, Sal)
        {
            Kilometertravel = kmt;
            TourAllowance = Kilometertravel * 5;
            TelephoneAllowance = 1000;
        }
        public override void Gsal()
        {
            GrossSalary = (GrossSalary + TourAllowance + TelephoneAllowance);
            Console.WriteLine(GrossSalary);
        }
        public override void CalculateSalary()
        {
            NetSalary = GrossSalary - (PF + TDS);
        }
    }
    class Mainp
    {
        static void Main(string[] args)
        {
            MarketingExe person = new MarketingExe(101, "Kirti", 8000, 10);
            person.Gsal();
        }
    }
}


