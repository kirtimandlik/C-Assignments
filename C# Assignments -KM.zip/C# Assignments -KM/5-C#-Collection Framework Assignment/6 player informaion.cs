﻿using System;
using System.Collections.Generic;
using System.Linq;
class Players
{
    String Name;
    int Runs;

public override string ToString()
    {
        return Name + " " + Runs + " ";
    }

public static void Main(string[] args)
{
    List<Players> Play = new List<Players>();
    {
        new Players { Name = "Dhoni", Runs = 100 };
        new Players { Name = "Yuvraj", Runs = 75 };
        new Players { Name = "Virat", Runs = 90 };
        new Players { Name = "Sachin", Runs = 99 };
        new Players { Name = "Rahul", Runs =80  };
    };


     IEnumerable<Players> result = Play.Where(x => x.Name[0] == 'S');

     Console.WriteLine("Players Name and Runs scored : ");

     foreach (Players p in result)
     {
        Console.WriteLine(p.ToString());
     }
}
}
