﻿using System;
using System.Collections;
using System.Collections.Generic;

class Array1

{
    public static void Main()
    {

        List<int> elelist = new List<int>();

        for (int i = 1; i <= 5; i++)
        {
            elelist.Add(i);
        }

        Console.WriteLine("Elememts from list are : ");


        foreach (int k in elelist)
        {
            Console.WriteLine(k);
        }

        Console.WriteLine(" ");
        Console.WriteLine("After  Reversing the list is: ");

        elelist.Reverse();


        foreach (int k in elelist)
        {
            Console.WriteLine(k);

        }


        elelist.Sort();
        foreach (int k in elelist)
        {

            Console.WriteLine("  ");
            Console.WriteLine("list after sorting : ");
            Console.WriteLine(k);

        }


        elelist.Clear();

        Console.WriteLine(" ");
        Console.Write("Number of elements in the List after clear : ");
        Console.WriteLine(elelist.Count);
        Console.WriteLine("  ");


        List<string> elelist1 = new List<string>();

        elelist1.Add("kirti");
        elelist1.Add("Aarvi");
        elelist1.Add("Kiran");
        elelist1.Add("Nilesh");
        elelist1.Add("Rushi");
        elelist1.Add("Aboli");
        elelist1.Add("Sayli");

        Console.WriteLine("Elements present in the strings are:  ");


        foreach (string k in elelist1)
        {
            Console.WriteLine(k);

        }

        Console.WriteLine("  ");


        Console.WriteLine(" List After Reversing: ");

        elelist1.Reverse();


        foreach (string k in elelist1)
        {
            Console.WriteLine(k);

        }


        elelist1.Sort();

        foreach (string k in elelist1)
        {

            Console.WriteLine("Display list after sorting : ");
            Console.WriteLine(k);
            Console.WriteLine("  ");
        }


        elelist1.Clear();

        Console.WriteLine(" ");
        Console.Write("Number of elements in the List after clear operation: ");
        Console.WriteLine(elelist1.Count);
        Console.WriteLine("  ");

    }
}