﻿using System;

namespace Ass_5_array
{
    class ArrayList
    {
        static void Main()
        {
            string UserChoice=string.Empty;
            //string choice;
            
            Array stringArray = Array.CreateInstance(typeof(String), 5);
            stringArray.SetValue("Kirti", 0);
            stringArray.SetValue("Aarvi", 1);
            stringArray.SetValue("Nilesh", 2);
            stringArray.SetValue("Rushi", 3);
            stringArray.SetValue("Chanda", 4);

                Console.WriteLine("Original Array");
                Console.WriteLine("---------------------");
                Console.WriteLine("\n1 Sort Array: ");
                Console.WriteLine("\n2 Reverse Array: ");
                Console.WriteLine("\n3 Clear Array: ");
                Console.WriteLine("\n0 Exit: ");
                Console.WriteLine("\n Enter Your Choice: ");

                switch (UserChoice)
                {
                    case "1":
                        Console.WriteLine();
                        foreach (string str in stringArray)
                        {
                            Console.WriteLine(str);
                        }
                        Console.WriteLine();
                        Console.WriteLine("Sorted Array");
                        Console.WriteLine("---------------------");
                        Array.Sort(stringArray);
                        foreach (string str in stringArray)
                        {
                            Console.WriteLine(str);
                        }
                        break;

                    case "2":
                        foreach (string str in stringArray)
                        {
                            Console.WriteLine(str);
                        }
                        Console.WriteLine();
                        Console.WriteLine("Reversed Array");
                        Console.WriteLine("---------------------");
                        Array.Reverse(stringArray);
                        Array.Sort(stringArray, 2, 3);
                        foreach (string str in stringArray)
                        {
                            Console.WriteLine(str);
                        }
                        break;

                    case "3":

                        foreach (string str in stringArray)
                        {
                            Console.WriteLine(str);
                        }
                        Console.WriteLine();
                        Console.WriteLine("Clear Items");
                        Console.WriteLine("---------------------");
                        Array.Clear(stringArray, 1, 2);
                        foreach (string str in stringArray)
                        {
                        Console.WriteLine(str);
                        }

                        break;

                default:
                    Console.WriteLine("choice doesent match..");
                    break;


                }
            }

        private static Array CreateInstance(Type type, int v)
        {
            throw new NotImplementedException();
        }

        private void SetValue(string v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}
