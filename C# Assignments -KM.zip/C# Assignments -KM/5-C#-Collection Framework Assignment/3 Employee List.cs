﻿using System;
using System.Collections.Generic;


    class _3_Employee_List
    {
    public static void Main()
    {
        LinkedList<String> My_List = new LinkedList<string>();

        My_List.AddLast("Kirt");
        My_List.AddLast("aarvi");
        My_List.AddLast("Pooja");
        My_List.AddLast("Rohini");
        My_List.AddLast("Rutija");
        My_List.AddLast("Anuja");
        My_List.AddLast("Ravi");

        Console.WriteLine("Name of Employees: ");
        Console.WriteLine("   ");

        foreach(string str in My_List)
        {
            Console.WriteLine(str);
            Console.WriteLine("    ");
        }

        if (My_List.Count > 0)
        {
            Console.WriteLine(My_List.Count);
        }

        else
        {
            Console.WriteLine("There is no best employee");
        }

        Console.WriteLine("    ");
        Console.WriteLine(My_List.Contains("nilesh"));

    }
}




