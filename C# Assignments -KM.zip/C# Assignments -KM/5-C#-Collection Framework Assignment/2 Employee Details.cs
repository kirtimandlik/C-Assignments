﻿
using System;
using System.Collections;

public class Employee_Details
{
    public static void Main()
    {
        var List1 = new ArrayList();

        List1.Add(1);
        List1.Add("Kirti");
        List1.Add(30000);
        List1.Add("  ");

        var List2 = new ArrayList();
        {
            List2.Add(2);
            List2.Add("Aarvi");
            List2.Add(40000);
            List2.Add("  ");

        };

        Console.WriteLine(" Details of Employee 1 : ");
        Console.WriteLine(List1[0]);
        Console.WriteLine(List1[1]);
        Console.WriteLine(List1[2]);
        Console.WriteLine(List1[3]);


        Console.WriteLine(" Details of Employee 2 : ");
        Console.WriteLine(List2[0]);
        Console.WriteLine(List2[1]);
        Console.WriteLine(List2[2]);
        Console.WriteLine(List2[3]);

    }
}



