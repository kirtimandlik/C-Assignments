﻿using System;

namespace oop_class_assignment_2
{
    internal class Program
    {
        class Employee
        {
            private int Eno;
            private string EmpName;
            private double salary;
            private double HRA;
            private double TA;
            private double DA;
            private double PF;
            private double TDS;
            private double NetSalary;
            private double GrossSalary;

            public Employee(int Eno, string EmpName, double salary)
            {
                Eno=Eno;
                EmpName=EmpName;
                salary=salary;

                if (salary < 5000)
                {
                    HRA = salary * 10 / 100;
                    TA = salary * 5 / 100;
                    DA = salary * 15 / 100;
                    GrossSalary = salary + HRA + TA + DA;
                }
                else if (salary < 10000)
                {
                    HRA = salary * 15 / 100;
                    TA = salary * 10 / 100;
                    DA = salary * 20 / 100;
                    GrossSalary = salary + HRA + TA + DA;
                }

                else if (salary < 15000)
                {
                    HRA = salary * 20 / 100;
                    TA = salary * 15 / 100;
                    DA = salary * 25 / 100;
                    GrossSalary = salary + HRA + TA + DA;
                }

                else if (salary < 20000)
                {
                    HRA = salary * 25 / 100;
                    TA = salary * 20 / 100;
                    DA = salary * 30 / 100;
                    GrossSalary = salary + HRA + TA + DA;
                }

                else if(salary >= 20000)
                {
                    HRA = salary * 30 / 100;
                    TA = salary * 25 / 100;
                    DA = salary * 35 / 100;
                    GrossSalary = salary + HRA + TA + DA;
                }
            }

            public void CalculateSalary()
            {
                PF = GrossSalary * 10 / 100;
                PF = GrossSalary * 10 / 100;
                TDS = GrossSalary * 18 / 100;

                NetSalary = GrossSalary -(PF+TDS);
            }

            public void displayEmployeeDetails()
            {
                Console.WriteLine("Employee number" + Eno + "Employee name" + EmpName + "Employee Salary" + salary);
            }
            public double DisplayGrossSalary()
            {
               return GrossSalary;          
            }
            

            static void Main(string[] args)
            {
                Employee emp = new Employee(105, "ABC", 7000.00);

                double grossSalary = emp.DisplayGrossSalary();
                
                Console.WriteLine("Gross Salary of Employee is:-" + grossSalary);
                Console.ReadKey();


            }
        }

    }

}

