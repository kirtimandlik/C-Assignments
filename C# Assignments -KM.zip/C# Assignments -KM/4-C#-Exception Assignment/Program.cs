﻿using System;

namespace Ass4_Exception
{
    class Stack
    {
        public int[] value;
        public int top;
        public int max;
        public Stack(int size)
        {
            value = new int[size];
            top = -1;
            max = size;
        }
        public void push(int item)
        {
            if (top == max - 1)
            {
                throw new Exception("stack overflow can't perform push");
            }
            value[++top] = item;
        }

        public int pop()
        {
            if (top == -1)
            {
                throw new Exception("stack is empty");

            }
            else
            {
                Console.WriteLine("poped element is " + value[top]);
                return value[top--];
            }


            for (int i = 0; i == top; i++)
            {
                Console.WriteLine("item [" + (i + 1) + "]:" + value[i]);
            }
        }
    }
    class program
    {
        public static void Main(string[] args)
        {
            Stack s = new Stack(5);

            s.push(10);
            s.push(20);
            s.push(30);
            s.push(40);
            s.push(50);
            //.push(60);

            Console.WriteLine("items are: ");
            Console.ReadKey();

            s.pop();
            s.pop();
            s.pop();
            s.pop();
            s.pop();

            Console.ReadKey();


        }

    }
}