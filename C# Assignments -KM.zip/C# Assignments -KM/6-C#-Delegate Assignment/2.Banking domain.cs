﻿using System;

namespace delegates
{
    class Account
    {
        //private double bal = 10000;

        public double bal
        {
            get { return bal; }
            set { bal = value; }
        }
    }

    public class Functions
    {
        Account acc = new Account();
        string CustomerName;
        int AccNumber;
        double withdraw, deposit, totalbal;

        public void Deposite()
        {
            Console.WriteLine("Enter Name: ");
            CustomerName = Console.ReadLine();

            Console.WriteLine("Enter Account Number:");
            AccNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Amount to be deposite:");
            deposit = Convert.ToDouble(Console.ReadLine());
            totalbal = acc.bal + deposit;
        }

        public void Withdraw()
        {
            Console.WriteLine("Enter Name of Account holder: ");
            CustomerName = Console.ReadLine();

            Console.WriteLine("Enter Account Nuber: ");
            AccNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Withdraw amount: ");
            withdraw = Convert.ToDouble(Console.ReadLine());

            if (withdraw <= acc.bal)
            {
                totalbal = acc.bal - withdraw;
                Console.WriteLine("AccountName: " + CustomerName);

            }

        }
    }
}

    