﻿using System;

namespace delegates
{
    class Banking
    {
        public delegate void methoddelegate(int a);

        public class Account
        {
            public int Accnumber { get; set; }
            public string CustomerName { get; set; }

            public int AccBalance = 10000;

            public event methoddelegate UnderBalance;
            public event methoddelegate ZeroBalance;

            public void Insufficient(int a)
            {
                UnderBalance(a);
            }

            public void DepositMoney(int b)
            {
                ZeroBalance(b);
            }

            public void Withdraw(int a)
            {
                if (a < AccBalance && AccBalance != 0)
                {
                    Console.WriteLine("Transaction Successful.");
                    Console.WriteLine("Remaining Balance is" + (AccBalance - a));
                }
                else if (a > AccBalance && AccBalance != 0)
                {
                    Console.WriteLine("Insufficient Balance");
                    Console.WriteLine("Your Current Balance is" + AccBalance);
                }
                else
                {
                    Console.WriteLine("ZeroBalance:" + AccBalance);
                }
            }

            public void Deposit(int a)
            {
                Console.WriteLine("Balance after depositing:" + (AccBalance + a));

            }
        }

        static void Main(string[] args)
        {
            Account obj = new Account();
            Console.WriteLine("Enter your choice to withdaw or deposit: w or d");
            string wd = Console.ReadLine();
            if (wd == "w")
            {
                Console.WriteLine("Enter amount to be withdraw:");
                int wdBalance = Convert.ToInt32(Console.ReadLine());
                obj.UnderBalance += new methoddelegate(obj.Withdraw);
                obj.Insufficient(wdBalance);
            }
            else
            {
                Console.WriteLine("Enter Deposite amount:");
                int DpBalance = Convert.ToInt32(Console.ReadLine());
                obj.ZeroBalance += new methoddelegate(obj.Deposit);
                obj.DepositMoney(DpBalance);
            }
            Console.ReadKey();
        }
    }
}
