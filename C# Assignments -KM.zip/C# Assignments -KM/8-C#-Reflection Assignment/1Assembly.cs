﻿using System;
using System.Reflection;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter External Assembly:");
            string typName = Console.ReadLine();
            try
            {
               //Create External TestLib.dll
                Assembly asm = Assembly.LoadFrom(@"E:/TestLib.dll ");
                DispalyAssembly(asm);
            }
            catch
            {
                Console.WriteLine("Can't Load Assembly");
            }
            //try
            //{
            //    Assembly asm = Assembly.Load(typName);
            //    DispalyAssembly(asm);
            //}
            //catch
            //{
            //    Console.WriteLine("Can't Load Assembly");
            //}
            //Console.ReadKey();
        }

        static void DispalyAssembly(Assembly a)
        {
            Console.WriteLine("*******Contents in Assembly*********");
            Console.WriteLine("Information:{0}", a.FullName);
            Type[] asm = a.GetTypes();
            foreach (Type tp in asm)
            {
                Console.WriteLine("Type:{0}", tp);
            }
        }
    }
}
