﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reflection_Assignment
{
    class Attribute
    {
        private string ProjectName { get; set; }
        private string Description { get; set; }
        private string ClientName { get; set; }
        private string StartedDate { get; set; }
        private string EndDate { get; set; }
        
        static void Main(string[] args)
        {
        }
    }
}
