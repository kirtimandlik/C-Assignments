﻿using System;

namespace calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            string operand;
            float answer;

            Console.Write("Enter 1st number: ");
            a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 2nd number: ");
            b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please enter any operand(+,-,/,*): ");

            operand = Console.ReadLine();

            switch (operand)
            {
                case "+":
                    answer = a + b;
                    Console.WriteLine("Addition Of Two Numbers : " + (a + b));
                    break;
                case "-":
                    answer = a - b;
                    Console.WriteLine("Subtraction Of Two Numbers : " + (a - b));
                    break;
                case "/":
                    answer = a / b;
                    Console.WriteLine("Division Of Two Numbers : " + (a / b));
                    break;
                case "*":
                    answer = a * b;
                    Console.WriteLine("Multiplicaion Of Two Numbers : " + (a * b));
                    break;

                default:
                    Console.WriteLine(" Please enter your choice ");
                    break;
            }
            Console.ReadLine();
        }
    }
    }

