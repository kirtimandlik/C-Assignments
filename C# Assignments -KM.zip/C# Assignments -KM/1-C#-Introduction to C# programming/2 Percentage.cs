﻿using System;

public class Students
{
    static void Main(string[] args)
    {
        double rollno, phy, chem, comp, total;
        double per;
        string name, div;

        Console.Write("\n\n");
        Console.Write("Calculate the total, percentage and division to take marks of three subjects:\n");
        Console.Write("-------------------------------------------------------------------------------");
        Console.Write("\n\n");


        Console.Write("Input the Roll Number of the student :");
        rollno = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input the Name of the Student :");
        name = Console.ReadLine();

        Console.Write("Input  the marks of Physics : ");
        phy = Convert.ToInt32(Console.ReadLine());
        
        Console.Write("Input  the marks of  Chemistry : ");
        chem = Convert.ToInt32(Console.ReadLine());
        
        Console.Write("Input  the marks of Computer Application : ");
        comp = Convert.ToInt32(Console.ReadLine());

        total = phy + chem + comp;
        per = total / 3.0;
        if (per >= 60)
            div = "First";
        else
        if (per < 60 && per >= 48)
            div = "Second";
        else
            if (per < 48 && per >= 36)
            div = "Pass";
        else
            div = "Fail";

        Console.Write("\nRoll No : {0}\nName of Student : {1}\n", rollno, name);
        Console.Write("Marks in Physics : {0}\nMarks in Chemistry : {1}\nMarks in Computer Application : {2}\n", phy, chem, comp);
        Console.Write("Total Marks = {0}\nPercentage = {1}\nDivision = {2}\n", total, per, div);
    }
}
