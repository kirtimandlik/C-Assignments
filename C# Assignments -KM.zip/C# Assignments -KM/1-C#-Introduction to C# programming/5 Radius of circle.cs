﻿using System;
public class Radius
{
    public static void Main()
    {

        double r, per_cir;
        double PI = 3.14;
        Console.WriteLine("Input the radius of the circle : ");
        r = Convert.ToDouble(Console.ReadLine());
        per_cir = 2 * PI * r;
        Console.WriteLine("Perimeter of Circle : {0}", per_cir);
        double Area = Math.PI * r * r;
        Console.WriteLine("Area of circle: " + Area);
        Console.Read();
    }
}