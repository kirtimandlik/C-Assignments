﻿namespace calculator
{
    internal class _6_Structure
    {
    }
}
