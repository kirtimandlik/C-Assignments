﻿using System;

namespace calculator
{
    internal class ass2_avg
    {
        static void Main()
        {
            int total = 0;
            int Count = 0;

            Console.WriteLine("How many students are there?");
            int students = int.Parse(Console.ReadLine());

            for (int y = 1; y <= students; y++)
            {
                Console.WriteLine("Enter student name");
                string name = Console.ReadLine();

                for (int x = 1; x <= 5; x++)
                {
                    Console.WriteLine("Enter your mark");
                    int mark = int.Parse(Console.ReadLine());

                    if (mark > 100 || mark < 0)
                    {
                        Console.WriteLine("Invalid mark,Enter your mark again");

                        int newmark = int.Parse(Console.ReadLine());
                        mark = newmark;
                    }

                    total += mark;

                    if (mark >= 50)
                    {
                        Count++;
                    }
                }
                Console.WriteLine("sum = " + total);

                double average = (total / 5.0) * 1.00;
                Console.WriteLine("average = " + average);

                Console.WriteLine("Greater or equal to 50 count = " + Count);
                Console.ReadLine();

                total = 0;
                Count = 0;
            }
        }
    }
}
